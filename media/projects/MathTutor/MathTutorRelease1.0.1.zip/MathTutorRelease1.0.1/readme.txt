Math Tutor
By Blue Sun Systems
Version 1.0.1
Release 100903

**************************************************************************************

Thank you for using Math Tutor!

To get started extract the MathTutor.zip to the folder of your choice
Double click on MathTutor.exe or use Cortana to run the file from the Windows search
bar. 

From the start up screen only the Teacher portal can be accessed until a faculty memeber
has successfully logged on and unlocked the studen portal.

The software comes pre-populated with a system admin profile. Use this profile to log
in for the first time. The System Admin profile can be logged in using these credentials

User ID# 100
Password: Password

After the first log in under the System Admin profile, Math Tutor will require the
password to be changed. 

!!!!!!!! Warning !!!!!!!!!!

Do not forget the System Admin Password as it will be imeadly needed to complete the
Log in. Until there are other faculty profiles added to Math Tutor this is the ONLY
profile that has access to the faculty menu.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Once the System Admin profile has been set up, and logged into using the new password,
the teacher menu will be oppened. From this menu additional faculty profiles may be
added using Faculty Roster. Press the '+' button on the top right and fill in the
fields except the Salt and Hash fields. Click the Set/Reset Password button under the
fields and allow the faculty memeber to set their password. Alternately if the faculty
member is not pressent, do not use the Set/Reset Password button but proceed to the
next step.

At this point it is imperitive that the data be saved to the database table. Do this 
by clicking the save icon next to the '+' button at the top right. Once this is done,
these steps can be repeated to add additional faculty members, or the form can be
closed to return to the teacher menu.

To unlock the student portal to allow access to the Math Tutor flash card and testing
functions, click on Unlock Student Access. 

When students are done using Math Tutor, from the Teacher Menu, click Log Off to 
log out any students still logged in, and lock the student portal. This will also 
log out any faculty members that are logged in, then close the Teacher Menu and return
to the Start Up Window.

To add student profiles, click on Student Roster from the Teacher Menu, then follow
the steps outlined for the Faculty Roster.

The remaining functions from the Teacher Menu are not yet available, but will become
useable once they are released and Math Tutor is updated with the release.